<?php
/**
 * As configurações básicas do WordPress
 *
 * O script de criação wp-config.php usa esse arquivo durante a instalação.
 * Você não precisa usar o site, você pode copiar este arquivo
 * para "wp-config.php" e preencher os valores.
 *
 * Este arquivo contém as seguintes configurações:
 *
 * * Configurações do MySQL
 * * Chaves secretas
 * * Prefixo do banco de dados
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/pt-br:Editando_wp-config.php
 *
 * @package WordPress
 */

// ** Configurações do MySQL - Você pode pegar estas informações com o serviço de hospedagem ** //
/** O nome do banco de dados do WordPress */
define( 'DB_NAME', 'ocp' );

/** Usuário do banco de dados MySQL */
define( 'DB_USER', 'root' );

/** Senha do banco de dados MySQL */
define( 'DB_PASSWORD', 'M0needer!@' );

/** Nome do host do MySQL */
define( 'DB_HOST', 'localhost' );

/** Charset do banco de dados a ser usado na criação das tabelas. */
define( 'DB_CHARSET', 'utf8mb4' );

/** O tipo de Collate do banco de dados. Não altere isso se tiver dúvidas. */
define('DB_COLLATE', '');

/**#@+
 * Chaves únicas de autenticação e salts.
 *
 * Altere cada chave para um frase única!
 * Você pode gerá-las
 * usando o {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org
 * secret-key service}
 * Você pode alterá-las a qualquer momento para invalidar quaisquer
 * cookies existentes. Isto irá forçar todos os
 * usuários a fazerem login novamente.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         ' C@x-;Rd(t(9EZ~;f~ONOZmHWG x`kj#wy1=K)*)rE^c!ul^OM:u1TE5&DTE?&f-' );
define( 'SECURE_AUTH_KEY',  'G5I@U$o$)}JIASr.PLC.1XU4jx[J^;x?I aZ_eCMR]Wc:*n?QbbWzj7_aCas[rJC' );
define( 'LOGGED_IN_KEY',    'P+wUput/i`G`?m/vVO7M0|_C|ImI*6BiP(`z5vw>}i7g!DW3KbQ;rZPCG<8>;>e[' );
define( 'NONCE_KEY',        '9po:zn.o44Pf[K^|!?uLOaQ/AZyYD*F};/=Wrs(m/b2-EaQ&iNK4?%JE{=R|v.Fb' );
define( 'AUTH_SALT',        '_4wh56JwF{{^gkel_^ncx1sk1;`.I<RObVia#w8Dvw88vs y]q&v6+n+ae0$h^IY' );
define( 'SECURE_AUTH_SALT', ' H|,yt <zdR&#J|#[kn,AUh&$UM7VAj*(7hEbr9oxnKQ8;L%v=8&Ufp:q@m*.KC`' );
define( 'LOGGED_IN_SALT',   '09SOf@C5ai=s0)=[#do]d`1_8A;6}?h*%tNEXx;WoERUkznxOm(e6-rB[Znj%=J#' );
define( 'NONCE_SALT',       '..cYhWyu,lb]w:uVN6DldqV.YMtYcu/G^U>a_5*%rfN$-{G4PZmIE$SZL^bo9l2#' );

/**#@-*/

/**
 * Prefixo da tabela do banco de dados do WordPress.
 *
 * Você pode ter várias instalações em um único banco de dados se você der
 * um prefixo único para cada um. Somente números, letras e sublinhados!
 */
$table_prefix = 'wp_';

/**
 * Para desenvolvedores: Modo de debug do WordPress.
 *
 * Altere isto para true para ativar a exibição de avisos
 * durante o desenvolvimento. É altamente recomendável que os
 * desenvolvedores de plugins e temas usem o WP_DEBUG
 * em seus ambientes de desenvolvimento.
 *
 * Para informações sobre outras constantes que podem ser utilizadas
 * para depuração, visite o Codex.
 *
 * @link https://codex.wordpress.org/pt-br:Depura%C3%A7%C3%A3o_no_WordPress
 */
define('WP_DEBUG', false);

/* Isto é tudo, pode parar de editar! :) */

/** Caminho absoluto para o diretório WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Configura as variáveis e arquivos do WordPress. */
require_once(ABSPATH . 'wp-settings.php');
